/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proj_18;

/**
 *
 * @author w.rocha
 */
public class Proj_18 {

    public static void main(String[] args) {
        
    }
}
